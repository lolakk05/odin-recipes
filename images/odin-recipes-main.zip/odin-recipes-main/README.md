# Recipes List

## Links
- [Try Recipes List here!](https://Appletri.github.io/odin-recipes)

- [Link to the Assignment](https://www.theodinproject.com/paths/foundations/courses/foundations/lessons/recipes)

## About
A simple webpage made during the foundations course on the Odin Project. Clicking on a recipe link will show the instructions and ingredients required to make the dish.

## Screenshots
![](https://github.com/Appletri/Appletri/blob/main/assets/odin-recipes-1.JPG)
![](https://github.com/Appletri/Appletri/blob/main/assets/odin-recipes-2.JPG)
![](https://github.com/Appletri/Appletri/blob/main/assets/odin-recipes-3.JPG)
